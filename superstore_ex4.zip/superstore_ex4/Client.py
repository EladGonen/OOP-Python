class Client:
    def __init__(self, client_id, name, email, address, phone_number, gender):
        self.client_id = client_id
        self.name = name
        self.email = email
        self.address = address
        self.phone_number = phone_number
        self.gender = gender
        if '@' not in self.email:
            self.email = name + '@mail.com'

        if len(str(phone_number)) != 10:
            self.phone_number  = '0000000000'
        if gender != 'F' and gender != 'M':
            self.gender = 'M'

    def print_me(self):
        print(f'----{self.client_id}----\n' f'Name:{self.name} \n' f'Email:{self.email} \n' f'Address:{self.address} \n' f'Phone_number:{self.phone_number} \n' f'Gender:{self.gender}')



    def __str__(self):
        return (f'{self.client_id}, {self.name}, {self.email}, {self.address}, {self.phone_number}, {self.gender}')

    def __repr__(self):
        return (self.client_id, self.name, self.email, self.address, self.phone_number, self.gender)

