from Product import Product
from Client import Client
from Laptop import Laptop
from Smartphone import Smartphone
from Order import Order
from Shirts import Shirts
from Exceptions import ClientNotFoundError, ShirtNotFoundError
import csv


class Superstore:
    def __init__(self, products_supply, clients, shirts, orders):
        self.products = []
        self.clients = []
        self.orders = []
        self.shirts = []

        with open("products_supply.csv") as products_supply:
            read = csv.reader(products_supply)
            next(read)
            for row in read:
                if row[1] == "laptop":
                    pr = Laptop(int(row[0]), row[2], row[3], int(row[4]), float(row[5]), row[6], int(row[7]),
                                int(row[8]))
                elif row[1] == "smartphone":
                    pr = Smartphone(int(row[0]), row[2], row[3], int(row[4]), float(row[5]), row[9], int(row[10]),
                                    int(row[11]))
                else:
                    pr = Product(int(row[0]), row[2], row[3], int(row[4]), float(row[5]))

                self.products.append(pr)

        with open("clients.csv") as clients:
            read = csv.reader(clients)
            next(read)
            for row in read:
                client_id = int(row[0])
                name = row[1]
                email = row[2]
                address = row[3]
                phone_number = row[4]
                gender = row[5]
                cl = Client(client_id, name, email, address, phone_number, gender)
                self.clients.append(cl)

        with open("shirts.csv") as shirts:
            read = csv.reader(shirts)
            next(read)
            for row in read:
                product_id = int(row[0])
                product_name = row[1]
                price = int(row[2])
                units_in_stock = int(row[3])
                shirt = Shirts(product_id, product_name, price, units_in_stock)
                self.shirts.append(shirt)

        with open("orders.csv") as orders:
            read = csv.reader(orders)
            next(read)
            for row in read:
                order_id = int(row[0])
                client_id = int(row[1])
                product_id = int(row[2])
                quantity = int(row[3])
                ord = Order(order_id, client_id, product_id, quantity)
                self.orders.append(ord)

    def get_all_phones(self):
        all_phones = ''
        for i in self.products:
            if type(i).__name__ == 'Smartphone':
                all_phones = all_phones + '\n' + str(i)
        return all_phones

    def get_all_laptops(self):
        all_laptops = ''
        for i in self.products:
            if type(i).__name__ == 'Laptop':
                all_laptops = all_laptops + '\n' + str(i)
        return all_laptops

    def phone_average_price(self):
        all_phones = []
        for i in self.products:
            if type(i).__name__ == 'Smartphone':
                all_phones.append(i)
        phones = all_phones
        count = 0
        sum = 0
        for i in phones:
            count += 1
            sum = sum + i.price
        avg_price = sum / count
        return avg_price

    def get_max_screen(self):
        all_laptops = []
        for i in self.products:
            if type(i).__name__ == 'Laptop':
                all_laptops.append(i)
        max_screen = 0
        for i in all_laptops:
            if i.screen > max_screen:
                max_screen = i.screen
        return max_screen

    def get_common_cam(self):
        all_phones = []
        for i in self.products:
            if type(i).__name__ == 'Smartphone':
                all_phones.append(i)
        phones = all_phones
        cam_res_list = []
        for i in phones:
            cam_res_list.append(i.cam_res)
        return max(set(cam_res_list), key=cam_res_list.count)

    def list_popular(self):
        popular_products = ''
        for i in self.products:
            if i.is_popular():
                popular_products = popular_products + '\n' + str(i)
        return popular_products

    def print_products(self):
        product_line = ''
        for i in self.products:
            product_line = product_line + '\n' + str(i)
        print(product_line)

    def get_product(self, product_id):
        for i in self.products:
            if i.product_id == product_id:
                return f'{i.product_id},{i.brand},{i.model},{i.year},{i.price}'
        return None

    def remove_product(self, pr_check):
        for i in self.products:
            if i.product_id == pr_check:
                self.products.remove(i)
                return True
        return False

    def get_all_by_brand(self, brand_name):
        brand_total_list = []
        for i in self.products:
            if i.brand == brand_name:
                brand_total_list.append(i)
        return brand_total_list

    def get_all_by_price_under(self, user_price):
        below_price_list = ''
        for i in self.products:
            if i.price < user_price:
                below_price_list = below_price_list + '\n' + str(i)
        return below_price_list

    def get_most_expensive_product(self):
        exp_price = 0
        exp_product = ''
        for i in self.products:
            if i.price > exp_price:
                exp_price = i.price
                exp_product = i
        return exp_product

    def print_clients(self):
        client_info = ''
        for i in self.clients:
            client_info = client_info + '\n' + str(i)
        print(client_info)

    def get_client(self, client_id):
        for i in self.clients:
            if i.client_id == client_id:
                return i
        return None

    def add_client(self, added_client):
        for i in self.clients:
            if i.client_id == added_client.client_id:
                return False
        self.clients.append(added_client)
        return True

    def remove_client(self, cl_check):
        for i in self.clients:
            if i.client_id == cl_check:
                self.clients.remove(i)
                return True
        return False

    def __iadd__(self, new_prod):
        for i in self.products:
            if i.product_id == new_prod.product_id:
                print("The product already exits in the file")
                return False
            else:
                self.products.append(new_prod)
                print("The product has been added successfully")
                return True



    def get_all_shirts(self):
        all_shirts = ''
        for i in self.shirts:
            all_shirts = all_shirts + '\n' + str(i)
        return all_shirts

    def get_all_orders(self):
        all_orders = ''
        for i in self.orders:
            all_orders = all_orders + '\n' + str(i)
        return all_orders

    def get_shirt(self, new_prod_id):
        for i in self.shirts:
            if i.product_id == new_prod_id:
                return i
        return None

    def get_max_order_id(self):
        max_id = 0
        for i in self.orders:
            if i.order_id > max_id:
                max_id = i.order_id
        return max_id

    def add_order(self, client_id, product_id, quantity):
        order_id = self.get_max_order_id() + 1
        client_exists = False
        product_exists = False

        for i in self.clients:
            if i.client_id == client_id:
                client_exists = True
                break
        if not client_exists:
            raise ClientNotFoundError(client_id)

        for i in self.products:
            if i.product_id == product_id and type(i).__name__ in ['Laptop', 'Smartphone']:
                product_exists = True
                available_quantity = 1
                if available_quantity < quantity:
                    raise ValueError(f'There are only {available_quantity} units available in stock,please re-order')
                break

        for i in self.shirts:
            if i.product_id == product_id and i.units_in_stock < quantity:
                raise ValueError(f'There are only {i.units_in_stock} units available in stock,please re-order')
            if i.product_id == product_id:
                product_exists = True
                break
        if not product_exists:
            raise ShirtNotFoundError(product_id)

        new_order = Order(order_id, client_id, product_id, quantity)
        self.orders.append(new_order)



