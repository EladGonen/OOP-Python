from Product import Product


class Laptop(Product):
    def __init__(self, product_id, brand, model, year, price, cpu, hard_disk, screen):
        super().__init__(product_id, brand, model, year, price)
        self.cpu = cpu
        self.hard_disk = hard_disk
        self.screen = screen

    def print_me(self):
        super().print_me()
        print(f'Cpu:{self.cpu} \n HardDisk:{self.hard_disk} \n Screen:{self.screen}')

    def __str__(self):
        return super().__str__() + f',{self.cpu},{self.hard_disk},{self.screen}'

    def __repr__(self):
        return super().__repr__(), self.cpu, self.hard_disk, self.screen

    def is_popular(self):
        return super().is_popular()
