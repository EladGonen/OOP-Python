from Product import Product

class Smartphone(Product):
    def __init__(self, product_id, brand, model, year, price, cell_net, num_cores, cam_res):
        super().__init__(product_id, brand, model, year, price)
        self.cell_net = cell_net
        self.num_cores = num_cores
        self.cam_res = cam_res

    def print_me(self):
        super().print_me()
        print(f'Cellular network:{self.cell_net} \n Number of cores:{self.num_cores} \n Camera resolution:{self.cam_res}')

    def __str__(self):
        return super().__str__() + f',{self.cell_net},{self.num_cores},{self.cam_res}'

    def __repr__(self):
        return super().__repr__(), self.cell_net, self.num_cores, self.cam_res

    def is_popular(self):
        return super().is_popular()

