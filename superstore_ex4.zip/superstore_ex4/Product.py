class Product:
    def __init__(self, product_id,  brand, model, year, price):
        self.product_id = product_id
        self.brand = brand
        self.model = model
        self.year = year
        self.price = price
        if len(str(self.year)) != 4:
            self.year = 2022 #default year chosen

    def print_me(self):
        print(f'----{self.product_id}----\n'  f'Brand:{self.brand} \n' f'Model:{self.model} \n' f'Year:{self.year} \n' f'Price:{self.price}')

    def __str__(self):
        return (f'{self.product_id},{self.brand},{self.model},{self.year},{self.price}')

    def __repr__(self):
        return str(self)

    def is_popular(self):
        if self.year >= 2017 and self.price <= 3000:
            return True
        return False

