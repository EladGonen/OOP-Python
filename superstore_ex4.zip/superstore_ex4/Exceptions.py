class ClientNotFoundError(Exception):
    def __init__(self, client_id):
        self.client_id = client_id

    def __str__(self):
        return f'Client with ID: {self.client_id} has not been found'


class ShirtNotFoundError(Exception):
    def __init__(self, product_id):
        self.product_id = product_id

    def __str__(self):
        return f'Product with ID: {self.product_id} has not been found'





