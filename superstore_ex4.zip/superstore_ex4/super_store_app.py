#Sergei Goldovsky- exercise 4- 322102005

from Superstore import Superstore
from tkinter import *
from tkinter import ttk, messagebox
from Laptop import Laptop
from Smartphone import Smartphone
import csv

s_store = Superstore("products_supply.csv", "clients.csv", "shirts.csv", "orders.csv")
win = Tk()
win.title('Super Store App')
win.geometry("750x780")
app_icon = PhotoImage(file='shopping cart.png')
win.iconphoto(True, app_icon)
win.config(background="#cbbeb5")

# labels:
head_label = Label(win, text='Super Store', bg="#cbbeb5", fg='#8444ff', font=('Helvetica', 18, 'bold'))
head_label.grid(row=1, column=0)
prd_head_label = Label(win, text='Products', bg="#cbbeb5", fg='#10aded', font=('Helvetica', 16, 'bold'))
prd_head_label.place(x=20, y=40)
display_prd_button = Button(win, text="Display products", fg='#1555bd', width=15, height=2)
display_prd_button.place(x=150, y=80)

# combobox:
prd_combo_box = ttk.Combobox(win, values=["All products", "Laptops", "Smartphones", "Shirts"])
prd_combo_box.place(x=15, y=80)
prd_combo_box.configure(width=10)

# listbox:
products_list_box = Listbox(win, width=47, height=9)
products_list_box.place(x=300, y=80)
prod_options = ["All products", "Laptops", "Smartphones", "Shirts"]

# part 2 interface:
create_new_prd_label = Label(win, text='Create New Product', bg="#cbbeb5", fg='#10aded', font=('Helvetica', 16, 'bold'))
create_new_prd_label.place(x=20, y=240)
id_label = Label(win, text='Id', bg="#cbbeb5", font=('Helvetica', 12))
id_label.place(x=20, y=290)
id_entry = Entry(win, width=15)
id_entry.place(x=20, y=310)
price_label = Label(win, text='Price', bg="#cbbeb5", font=('Helvetica', 12))
price_label.place(x=200, y=290)
price_entry = Entry(win, width=15)
price_entry.place(x=200, y=310)
brand_label = Label(win, text='Brand', bg="#cbbeb5", font=('Helvetica', 12))
brand_label.place(x=380, y=290)
brand_entry = Entry(win, width=15)
brand_entry.place(x=380, y=310)
model_label = Label(win, text='Model', bg="#cbbeb5", font=('Helvetica', 12))
model_label.place(x=560, y=290)
model_entry = Entry(win, width=15)
model_entry.place(x=560, y=310)

year_label = Label(win, text='Year', bg="#cbbeb5", font=('Helvetica', 12))
year_label.place(x=20, y=360)

year_combo_box = ttk.Combobox(win, values=[i for i in range(1970, 2024)])
year_combo_box.place(x=20, y=380)
year_combo_box.configure(width=13)

cpu_label = Label(win, text='CPU', bg="#cbbeb5", font=('Helvetica', 12))
cpu_label.place(x=200, y=440)
cpu_entry = Entry(win, width=15)
cpu_entry.place(x=200, y=460)

hard_disk_label = Label(win, text='Hard disk', bg="#cbbeb5", font=('Helvetica', 12))
hard_disk_label.place(x=380, y=440)
hard_disk_entry = Entry(win, width=15)
hard_disk_entry.place(x=380, y=460)

screen_label = Label(win, text='Screen', bg="#cbbeb5", font=('Helvetica', 12))
screen_label.place(x=560, y=440)
screen_entry = Entry(win, width=15)
screen_entry.place(x=560, y=460)

cell_label = Label(win, text='Cellular Network', bg="#cbbeb5", font=('Helvetica', 12))
cell_label.place(x=200, y=510)
cell_entry = Entry(win, width=15)
cell_entry.place(x=200, y=530)

cores_label = Label(win, text='Number of cores', bg="#cbbeb5", font=('Helvetica', 12))
cores_label.place(x=380, y=510)
cores_entry = Entry(win, width=15)
cores_entry.place(x=380, y=530)

cam_res_label = Label(win, text='Camera resolution', bg="#cbbeb5", font=('Helvetica', 12))
cam_res_label.place(x=560, y=510)
cam_res_entry = Entry(win, width=15)
cam_res_entry.place(x=560, y=530)

# radiobuttons:
product_type = StringVar()


def select_option():
    selected = product_type.get()
    if selected == "Laptop":
        cpu_entry.config(state='normal')
        hard_disk_entry.config(state='normal')
        screen_entry.config(state='normal')
        cell_entry.config(state='disable')
        cores_entry.config(state='disable')
        cam_res_entry.config(state='disable')
    elif selected == "Smartphone":
        cell_entry.config(state='normal')
        cores_entry.config(state='normal')
        cam_res_entry.config(state='normal')
        cpu_entry.config(state='disable')
        hard_disk_entry.config(state='disable')
        screen_entry.config(state='disable')


laptop_rb = Radiobutton(win, bg="#cbbeb5", text="Laptop", variable=product_type, value="Laptop", command=select_option)
laptop_rb.place(x=20, y=440)
smartphone_rb = Radiobutton(win, bg="#cbbeb5", text="Smartphone", variable=product_type, value="Smartphone",
                            command=select_option)
smartphone_rb.place(x=20, y=510)


def display_products():
    selected_option = prd_combo_box.get()
    products_list_box.delete(0, END)
    if selected_option == "All products":
        for i in s_store.products:
            products_list_box.insert(END, i)
        for i in s_store.shirts:
            products_list_box.insert(END, i)
    elif selected_option == "Laptops":
        for i in s_store.products:
            if type(i) is Laptop:
                products_list_box.insert(END, i)
    elif selected_option == "Smartphones":
        for i in s_store.products:
            if type(i) is Smartphone:
                products_list_box.insert(END, i)
    else:
        for i in s_store.shirts:
            products_list_box.insert(END, i)


error_label = Label(win, bg="#cbbeb5", font=('Helvetica', 11), text='', fg='red', wraplength=200)
error_label.place(x=20, y=270)
# for bonus part:
delete_error_label = Label(win, bg="#cbbeb5", font=('Helvetica', 11), text='', fg='red', wraplength=200)
delete_error_label.place(x=20, y=625)

# set of ids to check if id exists there already
id_list = []
for i in s_store.products:
    id_list.append(i.product_id)


def add_new_product():
    try:
        new_product_id = id_entry.get()
        product_price = price_entry.get()
        product_brand = brand_entry.get()
        product_model = model_entry.get()
        product_year = year_combo_box.get()
        new_prod_type = product_type.get()
        if not new_product_id:
            id_entry.config(bg="red")
            raise ValueError("Please enter product ID.")
        id_entry.config(bg="white")
        if not new_product_id.isnumeric():
            raise ValueError("Product ID must be a number!")
        if int(new_product_id) in id_list:
            raise ValueError("Product with this ID already exists on file!")
        if not product_price:
            price_entry.config(bg="red")
            raise ValueError("Please enter product price.")
        price_entry.config(bg="white")
        if not product_price.isnumeric():
            raise ValueError("Price should be a number!")
        if not product_brand:
            brand_entry.config(bg="red")
            raise ValueError("Please enter product brand.")
        brand_entry.config(bg="white")
        if not product_model:
            model_entry.config(bg="red")
            raise ValueError("Please enter product model.")
        model_entry.config(bg="white")
        if not product_year:
            year_label.config(bg="red")
            raise ValueError("Please select product year.")
        year_label.config(bg="#cbbeb5")

        if new_prod_type == "Laptop":
            product_cpu = cpu_entry.get()
            product_hard_disk = hard_disk_entry.get()
            product_screen = screen_entry.get()
            if not product_cpu:
                cpu_entry.config(bg="red")
                raise ValueError("Please enter CPU.")
            cpu_entry.config(bg="white")
            if not product_hard_disk:
                hard_disk_entry.config(bg="red")
                raise ValueError("Please enter the hard disk.")
            hard_disk_entry.config(bg="white")
            if not product_hard_disk.isnumeric():
                raise ValueError("Hard disk should contain numbers only!")
            if not product_screen:
                screen_entry.config(bg="red")
                raise ValueError("Please enter the screen size.")
            screen_entry.config(bg="white")
            if not product_screen.isnumeric():
                raise ValueError("Screen size should contain numbers only!")

            new_product = Laptop(new_product_id, product_brand, product_model, product_year, product_price, product_cpu,
                                 product_hard_disk, product_screen)
            s_store.products.append(new_product)
        elif new_prod_type == "Smartphone":
            product_cell_net = cell_entry.get()
            product_cores = cores_entry.get()
            product_resolution = cam_res_entry.get()
            if not product_cell_net:
                cell_entry.config(bg="red")
                raise ValueError("Please enter cellular network.")
            cell_entry.config(bg="white")
            if not product_cores:
                cores_entry.config(bg="red")
                raise ValueError("Please enter the number of cores.")
            cores_entry.config(bg="white")
            if not product_cores.isnumeric():
                raise ValueError("Cores must be a number!")
            if not product_resolution:
                cam_res_entry.config(bg="red")
                raise ValueError("Please enter the camera resolution.")
            cam_res_entry.config(bg="white")
            if not product_resolution.isnumeric():
                raise ValueError("Camera resolution should contain numbers only!")
            new_product = Smartphone(new_product_id, product_brand, product_model, product_year, product_price,
                                     product_cell_net, product_cores, product_resolution)
            s_store.products.append(new_product)
        messagebox.showinfo(message=f'The product has been created successfully! \n \n Product:{new_product}')
        id_entry.delete(0, END)
        price_entry.delete(0, END)
        brand_entry.delete(0, END)
        model_entry.delete(0, END)
        year_combo_box.set("")
        cpu_entry.delete(0, END)
        hard_disk_entry.delete(0, END)
        screen_entry.delete(0, END)
        cell_entry.delete(0, END)
        cores_entry.delete(0, END)
        cam_res_entry.delete(0, END)
        error_label.config(text='')
    except ValueError as e:
        error_label.config(text=e)


display_prd_button.config(command=display_products)

# create button:
create_prd_button = Button(win, text="Create", fg='#1555bd', width=16, height=2, command=add_new_product)
create_prd_button.place(x=560, y=720)

# Bonus part - i will add a delete button that will remove product from the product list box if an id exists on file:
# to check just press the display button before you press the delete button so you can find existing ids and then
# press the delete button and you will see it dissapear.
delete_prd_label = Label(win, text='Remove product', bg="#cbbeb5", fg='#10aded', font=('Helvetica', 16, 'bold'))
delete_prd_label.place(x=20, y=600)
new_id_label = Label(win, text='Id', bg="#cbbeb5", font=('Helvetica', 12))
new_id_label.place(x=20, y=640)
new_id_entry = Entry(win, width=15)
new_id_entry.place(x=20, y=660)


def del_product():
    try:
        new_id = new_id_entry.get()
        if not new_id:
            new_id_entry.config(bg="red")
            raise ValueError("Please enter product ID.")
        new_id_entry.config(bg="white")
        if not new_id.isnumeric():
            raise ValueError("Product ID must be a number!")
        if int(new_id) not in id_list:
            raise ValueError("There is no product with this ID on file!")
        index = id_list.index(int(new_id))
        products_list_box.delete(index)
        messagebox.showinfo(message=f'The product with ID: {new_id} has been removed from the product display list box!')
        new_id_entry.delete(0, END)
        delete_error_label.config(text='')
    except ValueError as e:
        delete_error_label.config(text=e)


delete_prd_button = Button(win, text="Delete", fg='#1555bd', width=16, height=2, command=del_product)
delete_prd_button.place(x=400, y=720)

win.mainloop()
